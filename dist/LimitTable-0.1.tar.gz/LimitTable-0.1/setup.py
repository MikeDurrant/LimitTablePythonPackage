from setuptools import setup

setup(name='LimitTable',
      version='0.1',
      description='Differential Calculus Limit Tables',
      packages=['calculus_limits'],
      zip_safe=False)